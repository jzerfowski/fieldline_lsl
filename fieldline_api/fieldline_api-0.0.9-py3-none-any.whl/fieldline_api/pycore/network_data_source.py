import threading
import zeroconf as zc
import socket
from collections import defaultdict
import logging
import json
from multiprocessing import Queue, Event
import queue
import time
import random

from pycore.interprocess_data import InterprocessDataPacketQueue
from pycore.data_source import DataSource
from pycore.network_client import NetworkClient
# import pycore.net_protocol_pb2 as proto
import net_protocol_pb2 as proto
from pycore import common


def recursive_defaultdict():
    """
    defaultdict that supports an arbitrary number of levels
    """
    return defaultdict(recursive_defaultdict)


class NetworkDataSource(DataSource):
    def __init__(self, interfaces, zeroconf_prefix, counter_lock, counter, hardware_state, developer_mode=False):
        DataSource.__init__(self, hardware_state)
        self.counter_lock = counter_lock
        self.counter = counter
        self.interfaces = interfaces
        self.zeroconf_prefix = zeroconf_prefix
        self.zeroconf = None
        self.restart_zeroconf()
        self.lock = threading.Lock()
        self.shutting_down = False
        self.services = {}
        self.last_timestamp = None
        self.sensor_config = recursive_defaultdict()
        self.status_msgs = {}
        self._zeroconf_name_to_chassis_name = {}
        self._chassis_name_to_zeroconf_name = {}
        self.chassis_name_to_id = {}
        self.last_connected = common.read_chassis_config()
        self.streaming_sources = {}
        self.closed_loop_enabled = False
        self.closed_loop_expected = False

        self.frame_q_lock = threading.Lock()
        self.RESET_THRESH = 1000
        self.SYNC_THRESH = 100
        self.reset_frame_buffer()
        self.frame_buffer = {}
        self.max_frame_buffer_size = 100

        self.discovered_devices = {}
        self.non_multi_devices = {}
        self.expect_device_reboot = {}
        self.update_chassis_version = {}

        self._developer_mode = developer_mode
        self._developer_mode_password = None
        self.stream_thread = None

        underrun_thread = threading.Thread(target=self.check_data_underrun_thread)
        underrun_thread.start()

    def __del__(self):
        self.shutdown(True)

    def reset_frame_buffer(self):
        with self.frame_q_lock:
            self.frame_q = {}
            self.frames_syncd = False
            self.no_sync = True
            self.last_frame = 0
            self.frames_expected_dict = {}
            self.frame_reset_pending = False
            self.frame_delta = None
            self.sync_active = {}
            self.last_ts = {}
            self.log_sync_error = True

    def restart_zeroconf(self):
        if self.zeroconf:
            logging.info("Stopping zeroconf")
            self.zeroconf.close()
            self.zeroconf = None
        logging.info("Starting zeroconf")
        self._zeroconf_name_to_chassis_name = {}
        self.zeroconf = zc.Zeroconf(self.interfaces)
        self.browser = zc.ServiceBrowser(self.zeroconf, "_http._tcp.local.",
                                         handlers=[self.on_zeroconf_service_state_change])

    def set_developer_mode(self, value):
        super(NetworkDataSource, self).set_developer_mode(value)
        if value:
            self.send_sensor_config_req()
        else:
            self.disable_chassis_developer_mode()

    def is_datatype_valid(self, sensor, data_type):
        if self._developer_mode:
            return True
        else:
            if sensor == 0:
                return data_type in common.CHASSIS_ACTIVE_REGISTERS.values()
            else:
                return data_type in common.ACTIVE_REGISTERS.values()

    def update_expected_chassis(self, chassis_name_to_id):
        self.last_connected = {}
        self.chassis_name_to_id = chassis_name_to_id
        for chassis_name, chassis_id in chassis_name_to_id.items():
            self.set_chassis_id(chassis_name, chassis_id)
        self.update_chassis_connections()

    def is_chassis_expected(self, chassis_name):
        return chassis_name in self.chassis_name_to_id

    def check_all_last_connected(self):
        if len(self.services) == len(self.last_connected):
            return
        logging.info("Last connected: %s" % self.last_connected)
        all_found = len(self.last_connected.keys()) > 0
        for name, chassis_id in self.last_connected.items():
            logging.info("Checking %s in %s" % (name, self.discovered_devices.keys()))
            if name not in self.discovered_devices.keys():
                logging.info("Not found")
                all_found = False
            else:
                properties = self.discovered_devices[name]
                if name in self.non_multi_devices:
                    continue
                elif len(self.last_connected.keys()) != int(properties['total']):
                    all_found = False
                elif chassis_id + 1 != int(properties['num']):
                    all_found = False
        if all_found:
            self.chassis_name_to_id = self.last_connected
            for name in self.last_connected.keys():
                self.connect_chassis(name)

    def get_chassis_names(self):
        return list(self.chassis_name_to_id.keys())

    def get_chassis_name_from_id(self, c_id):
        for name, chassis_id in self.chassis_name_to_id.items():
            if chassis_id == c_id:
                return name
        return None

    def get_chassis_list(self):
        ret = []
        for ch in self.discovered_devices.keys():
            sp = ch.split(":")
            ret.append(sp[0])
        return ret

    @property
    def active_services(self):
        active_services = {}
        for chassis_name, v in self.services.items():
            if self.is_chassis_expected(chassis_name):
                active_services[chassis_name] = v
        return active_services

    def disable_channel(self, chassis, sensor, data_type):
        logging.info("Disabling sensor %s %s %s" % (chassis, sensor, data_type))
        self.configure_sensor(chassis, sensor, data_type, 0)

    def configure_sensor(self, chassis, sensor, data_type, frequency, calibration=1.0):
        logging.info(f"Sensor configured: chassis={chassis} sensor={sensor}, data_type={data_type}, frequency={frequency} hz, calibration={calibration}")
        if not self.is_datatype_valid(sensor, int(data_type)):
            logging.warn(f"Data {data_type} is not valid")
            return
        self.sensor_config[chassis][sensor][data_type] = frequency
        chassis_id = self.chassis_name_to_id[chassis]
        self.hardware_state.configure_channel(
            chassis_id,
            sensor,
            data_type,
            frequency,
            calibration
        )
        with self.frame_q_lock:
            if not self.hardware_state.has_active_channels(chassis_id) and chassis_id in self.frame_q:
                logging.info("Chassis %d no longer has channels, removing from frame q" % chassis_id)
                del self.frame_q[chassis_id]

    def configure_sensor_list(self, chassis, sensor, channel_configs):
        channel_list = []
        for data_type, config in channel_configs.items():
            frequency, calibration = config
            self.configure_sensor(
                chassis=chassis,
                sensor=int(sensor),
                data_type=data_type,
                frequency=frequency,
                calibration=calibration
            )
            channel_list.append((int(sensor), data_type, frequency))
        chassis_id = self.chassis_name_to_id[chassis]
        sensor_name = "%02d:%02d" % (int(chassis_id), int(sensor))
        sensor_obj = self.get_sensor_from_name(sensor_name)

        for channel in sensor_obj.get_channels():
            if int(channel.data_index) not in channel_configs.keys():
                logging.info("NOT IN KEYS %s %s" % (channel.data_index, channel_configs.keys()))
                self.disable_channel(chassis, sensor, int(channel.data_index))
                channel_list.append((int(sensor), int(channel.data_index), 0))
        logging.info("channel lists: %s" % channel_list)

        if chassis in self.services:
            self.services[chassis].cmd_config_sensor_list(channel_list)

    def send_logic_module_command(self, chassis_id, sensor_id, data):
        chassis = self.get_chassis_name_from_id(chassis_id)
        self.send_raw_command(chassis, sensor_id, 260, data)

    def send_raw_command(self, chassis, sensor, address, data):
        if chassis not in self.active_services:
            logging.error(f"{chassis} is not a registered chassis, can not send raw command")
            return
        self.active_services[chassis].cmd_raw(sensor_num=sensor, register_address=address, data=data)

    def send_raw_command_by_chassis_id(self, chassis_id, sensor, address, data):
        chassis_name = None
        for c, c_id in self.chassis_name_to_id.items():
            if chassis_id == c_id:
                chassis_name = c
        if chassis_name is not None:
            self.send_raw_command(chassis_name, sensor, address, data)

    def send_logic_command(self, cmd_list):
        cmd_by_chassis = {}
        for c in cmd_list:
            chassis = self.get_chassis_name_from_id(c[0])
            if not chassis:
                continue
            if chassis not in cmd_by_chassis:
                cmd_by_chassis[chassis] = []
            cmd_by_chassis[chassis].append((c[1], c[2]))
        for chassis, l in cmd_by_chassis.items():
            if chassis not in self.active_services:
                logging.error(f"{chassis} is not a registered chassis, can not send logic command")
                continue
            self.active_services[chassis].cmd_logic(l)

    def send_one_time_read(self, chassis, sensor, address):
        if chassis not in self.active_services:
            logging.error(f"{chassis} is not a registered chassis, can not send one time read")
            return
        self.active_services[chassis].cmd_one_time_read(sensor_num=sensor, register_address=address)

    def save_sensor_config(self, filename):
        with open(filename, 'w') as f:
            json.dump(self.sensor_config, f)
        logging.info(f"Saved sensor configuration to {filename}")

    def load_sensor_config(self, filename):
        with open(filename, 'r') as f:
            sensor_config_from_file = json.load(f)

        channel_configs = {}
        for chassis, config in sensor_config_from_file.items():
            for sensor, dt_freq in config.items():
                for data_type, frequency in dt_freq.items():
                    self.configure_sensor(chassis, sensor, data_type, frequency)
                    if chassis not in channel_configs:
                        channel_configs[chassis] = []
                    channel_configs[chassis].append((int(sensor), int(data_type), int(frequency)))
        for chassis, channel_list in channel_configs.items():
            if chassis in self.services:
                self.services[chassis].cmd_config_sensor_list(channel_list)

    def quick_sensor_config(self, num_sensors, data_type, frequency, force=False):
        chassis_id_list = {}
        for svc in self.active_services.values():
            chassis_id_list[svc.chassis_id] = svc.chassis_name
        sensors = self.get_sensors()
        channel_configs = {}
        for sensor in sensors:
            if sensor.chassis_id in chassis_id_list.keys() and sensor.present and ((frequency > 0 and sensor.zerod) or (frequency == 0) or force):
                self.configure_sensor(chassis_id_list[sensor.chassis_id], sensor.sensor_id, data_type, frequency)
                if chassis_id_list[sensor.chassis_id] not in channel_configs:
                    channel_configs[chassis_id_list[sensor.chassis_id]] = []
                channel_configs[chassis_id_list[sensor.chassis_id]].append((sensor.sensor_id, data_type, frequency))
        logging.info("quick sensor configs: %s" % channel_configs)
        for chassis, channel_list in channel_configs.items():
            if chassis in self.services:
                self.services[chassis].cmd_config_sensor_list(channel_list)

    def send_update_command(self, uri):
        self.update_chassis_version = {}
        for chassis_name, chassis in self.active_services.items():
            self.update_chassis_version[chassis_name] = None
            self.expect_device_reboot[chassis_name] = self.discovered_devices[chassis_name]
            chassis.cmd_update(uri)

    def verify_post_update(self):
        ret = True
        vals_to_check = ['num', 'total', 'master', 'serial']
        for chassis_name, prop in self.expect_device_reboot.items():
            chassis_ok = True
            if chassis_name not in self.discovered_devices:
                chassis_ok = False
            else:
                for v in vals_to_check:
                    if prop[v] != self.discovered_devices[chassis_name][v]:
                        logging.error("chassis %s current val for %s of %s does not match original %s" % (chassis_name, v, prop[v], self.discovered_devices[chassis_name][v]))
                        chassis_ok = False
            if not chassis_ok:
                ret = False
                logging.error("verify update failed for chassis %s" % chassis_name)
        return ret

    def send_commit_command(self):
        self.update_chassis_version = {}
        for chassis_name, chassis in self.active_services.items():
            chassis.cmd_commit()

    def complete_update(self):
        for chassis_name, chassis in self.active_services.items():
            del self.expect_device_reboot[chassis_name]

    def send_reboot_command(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_reboot()

    def send_password(self, password):
        self._developer_mode_password = password
        for _, chassis in self.active_services.items():
            chassis.cmd_send_password(password)

    def send_sensor_config_req(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_sensor_config_req()

    def disable_chassis_developer_mode(self):
        for _, chassis in self.active_services.items():
            chassis.cmd_disable_developer_mode()

    def get_chassis_version(self, chassis_id):
        for c_name, c_id in self.chassis_name_to_id.items():
            if chassis_id == c_id and c_name in self.discovered_devices:
                return self.discovered_devices[c_name]['version']
        return None

    def get_update_info(self):
        ret = [None for i in range(len(self.chassis_name_to_id))]
        for chassis_name, chassis_id in self.chassis_name_to_id.items():
            version = None
            if chassis_name not in self.non_multi_devices:
                version = self.discovered_devices[chassis_name]['version']
            ret[chassis_id] = (chassis_name, version)
        return ret

    def all_versions_equal(self):
        if len(self.chassis_name_to_id) == 0:
            return True
        else:
            first_version = None
            for chassis_name, chassis_id in self.chassis_name_to_id.items():
                if chassis_name in self.non_multi_devices:
                    continue
                v = self.discovered_devices[chassis_name]['version']
                if not first_version:
                    first_version = v
                elif first_version != v:
                    return False
        return True

    def num_connections(self):
        return len(self.services)

    def stop_services(self):
        logging.info("Stopping services")
        for svc in self.services.values():
            svc.stop()
        for svc in self.services.values():
            svc.wait()
        self.update_chassis_connections()
        self.services = {}
        logging.info("Services are stopped")

    def shutdown(self, block=False):
        self.shutting_down = True
        self.stop()
        self.stop_services()

        if block:
            logging.info("Waiting for zeroconf to close...")
            self.zeroconf.close()
            logging.info("closed")
        else:
            t = threading.Thread(target=self.zeroconf.close)
            t.daemon = True
            t.start()

    def reset_chassis(self, chassis):
        self.active_services[chassis].cmd_reset()

    def ident_chassis(self, chassis, is_on):
        if chassis in self.services.keys():
            self.services[chassis].cmd_ident(is_on)
        elif chassis in self.discovered_devices.keys():
            logging.info("Chassis %s ident %s" % (chassis, is_on))
            chassis_properties = self.discovered_devices[chassis]
            NetworkClient.send_ident_request(is_on, chassis_properties['address'], chassis_properties['port'])
        else:
            logging.info("ident_chassis unable to find %s" % chassis)

    def connect_chassis_list(self, chassis_name_to_id):
        self.stop_services()
        self.chassis_name_to_id = chassis_name_to_id
        self.last_connected = chassis_name_to_id
        for chassis_name, chassis_id in chassis_name_to_id.items():
            self.connect_chassis(chassis_name)

    def connect_chassis(self, chassis_name):
        if chassis_name in self.discovered_devices.keys():
            if chassis_name is None:
                logging.error("Trying to connect to chassis with None name")
                return
            elif not self.is_chassis_expected(chassis_name):
                logging.error(f"{chassis_name} is NOT expected, skipping")
            chassis_properties = self.discovered_devices[chassis_name]
            name = chassis_properties['zeroconf']
            logging.info("Connecting to device: %s zeroconf: %s" % (chassis_name, name))

            data_queue = InterprocessDataPacketQueue(name + "-" + str(random.randint(1000, 9999)), True)
            new_service = NetworkClient(
                address=chassis_properties['address'],
                port=chassis_properties['port'],
                status_callback=self.update_state,
                raw_cmd_resp_callback=self._report_raw_cmd_resp,
                data_queue=data_queue,
                cmd_queue=Queue(),
                status_queue=Queue(),
                resp_queue=Queue(),
                shutdown_queue=Queue(),
                password_queue=Queue(),
                password_callback=self.password_callback,
                logger=logging,
                streaming_event=Event()
            )
            new_service.chassis_name = chassis_name
            self.services[chassis_name] = new_service
            self.set_chassis_id(chassis_name, self.chassis_name_to_id[chassis_name])
            new_service.start()
            self.update_chassis_connections()
            self.handle_chassis_connected(chassis_name)

    def on_zeroconf_service_state_change(self, zeroconf, service_type, name, state_change):
        if not name.startswith('%sFieldline' % self.zeroconf_prefix):
            return
        if self.shutting_down:
            logging.warn("Ignoring state change.. shutting down")
            return

        logging.info("ZeroConf discovery reports service %s of type %s %s" % (name, service_type, state_change))

        if state_change == zc.ServiceStateChange.Added:
            info = zeroconf.get_service_info(service_type, name)
            chassis_name = None
            properties = {}
            if info.properties:
                logging.info("PROPERTIES ARE: ")
                for key, value in info.properties.items():
                    try:
                        key = key.decode("utf-8")
                        value = value.decode("utf-8")
                    except Exception:
                        continue
                    logging.info("key %s val %s" % (key, value))
                    if key == "name":
                        chassis_name = value
                    else:
                        properties[key] = value
            old_type_device = "master" not in properties
            use_addr = None
            if len(info.addresses) == 1:
                use_addr = info.addresses[0]
            elif len(info.addresses) > 1:
                logging.info("Multiple addresses in info: %s" % info.addresses)
                use_addr = info.addresses[0]
            else:
                logging.error("No address found in info: %s" % info)
                return

            host, port = socket.inet_ntoa(use_addr), int(info.port)
            properties['address'] = host
            properties['port'] = port
            properties['zeroconf'] = name
            if old_type_device:
                self.non_multi_devices[chassis_name] = True
                logging.info("Old type device %s" % chassis_name)
            else:
                if chassis_name in self.update_chassis_version:
                    self.update_chassis_version[chassis_name] = properties['version']
            if chassis_name and chassis_name not in self.discovered_devices:
                self.discovered_devices[chassis_name] = properties
                self.discovered_devices[chassis_name]['closed_loop'] = None
                self._zeroconf_name_to_chassis_name[name] = chassis_name
                self._chassis_name_to_zeroconf_name[chassis_name] = name
                if chassis_name in self.expect_device_reboot:
                    logging.info(f"Expected reconnect {chassis_name}")
                    self.connect_chassis(chassis_name)
                else:
                    self.handle_chassis_added(chassis_name)
            logging.info("Discovered Devices: %s" % self.discovered_devices)

        elif state_change == zc.ServiceStateChange.Removed:
            if name in self._zeroconf_name_to_chassis_name:
                chassis_name = self._zeroconf_name_to_chassis_name[name]
                was_connected_device = False
                if chassis_name in self.discovered_devices:
                    del self.discovered_devices[chassis_name]
                if chassis_name in self.services:
                    was_connected_device = True
                if was_connected_device:
                    if chassis_name not in self.expect_device_reboot:
                        self.reset_connections("Chassis reconfiguration")
                    else:
                        logging.info(f"Stopping {chassis_name} on zeroconf removed")
                        svc = self.services.pop(chassis_name, None)
                        if svc:
                            svc.stop()
                            self.handle_chassis_removed(self._zeroconf_name_to_chassis_name[name])
                        self.update_chassis_connections()
        # else:
        #    logging.warn(f"Got unexpected zeroconf discovery change")

    def handle_chassis_added(self, chassis_name):
        self.check_all_last_connected()

    def handle_chassis_connected(self, chassis_name):
        pass

    def handle_chassis_removed(self, chassis_name):
        pass

    def is_chassis_configured(self, chassis_name):
        return self.services[chassis_name].chassis_name != 'unknown' and \
            self.services[chassis_name].chassis_name in self.chassis_name_to_id

    def reset_connections(self, reason):
        self.stop_services()
        self.restart_zeroconf()
        self.update_chassis_connections()
        self._handle_chassis_disconnect(reason)
        self.discovered_devices = {}

    def check_data_underrun_thread(self):
        while not self.shutting_down:
            total_samples_available = 0
            free_memory = []
            for i, (name, svc) in enumerate(self.active_services.items()):
                if not svc.is_alive and name not in self.expect_device_reboot:
                    logging.info(f"Chassis {name} has disconnected")
                    self.reset_connections("Chassis disconnected")
                    break
                total_samples_available += self.active_services[name].num_samples_available()
                free_memory.append(self.active_services[name].available_data_buf())
            if len(free_memory):
                avg_samples_per_chassis = total_samples_available / len(self.active_services) if len(self.active_services) else 0
                self._report_data_underrun(int(avg_samples_per_chassis), min(free_memory))
            time.sleep(2)

    def set_chassis_id(self, chassis_name, chassis_id):
        if chassis_name not in self.services:
            logging.error(f"{chassis_name} is not a recognized chassis")
            return
        self.services[chassis_name].chassis_id = chassis_id

    def password_callback(self, chassis_name, msg):
        if msg.dev_mode.enable:
            if msg.dev_mode.valid:
                self._report_password_response(chassis_name, True)
            else:
                self._report_password_response(chassis_name, False)

    def update_state(self, msg=None):
        with self.lock:
            # Remove any disconnected services
            self.services = {k: v for k, v in self.services.items() if not v.done.is_set()}
            if msg is not None:
                msg_chassis_id = None
                self._report_chassis_status(msg.chassis_name, msg.status)
                if not self.is_chassis_expected(msg.chassis_name):
                    logging.error(f"Got a sensor config packet for a non-active chassis {msg.chassis_name}")
                    return
                else:
                    msg_chassis_id = self.chassis_name_to_id[msg.chassis_name]
                if msg.HasField('chassis_status'):
                    if msg.chassis_status.HasField('closed_loop') and msg.chassis_name in self.discovered_devices:
                        self.discovered_devices[msg.chassis_name]['closed_loop'] = msg.chassis_status.closed_loop
                        self.check_closed_loop()
                if msg.type in (proto.StatusPacket.PROGRESS,):
                    self._report_update_progress(msg.chassis_name, msg.progress, msg.type, msg.progress_msg)
                elif msg.type == proto.StatusPacket.SENSOR_LED:
                    logging.debug("Got a SENSOR_LED message")
                    for s in self.get_sensors():
                        for sc in msg.sensor_led:
                            if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                                current_color = s.get_color()
                                current_blink = s.get_blink_state()
                                s.set_color(sc.color)
                                s.set_blink_state(sc.blink_state)
                                s.zerod = (sc.color == 6 and sc.blink_state == 1)
                                if current_color != sc.color or current_blink != sc.blink_state:
                                    self._handle_blink_state_changed(s.chassis_id, s.sensor_id, sc.color, sc.blink_state)
                    self._report_sensor_status_changed()
                elif msg.type == proto.StatusPacket.SENSOR_CONFIG:
                    logging.info("Got a SENSOR_CONFIG %s" % msg)
                    channel_list = []
                    chassis_id = self.chassis_name_to_id[msg.chassis_name]
                    for sc in msg.sensor_config:
                        if sc.HasField("calibration"):
                            calibration = sc.calibration
                        else:
                            calibration = 1.0
                        channel_list.append({'chassis_id': chassis_id,
                                             'sensor_id': sc.sensor,
                                             'data_type': sc.datatype,
                                             'frequency': sc.freq,
                                             'calibration': calibration
                                            })
                    self.hardware_state.configure_channel_list(chassis_id, channel_list)
                elif msg.type == proto.StatusPacket.SENSOR_STATUS:
                    logging.debug("Got a SENSOR_STATUS message")
                    for s in self.get_sensors():
                        for sc in msg.sensor_status:
                            if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                                if s.present != sc.sensor_connected:
                                    logging.info("Sensor connected changed to %s" % sc.sensor_connected)
                                s.present = sc.sensor_connected
                                s.card_serial = sc.sensor_card_serial_num
                                if sc.HasField('sensor_serial_num'):
                                    s.sensor_serial = sc.sensor_serial_num
                                else:
                                    s.sensor_serial = None
                    self._report_sensor_status_changed()
                elif msg.type == proto.StatusPacket.SENSOR_STATE:
                    for sc in msg.sensor_state:
                        logging.debug("Got SENSOR_STATE %d %s" % (sc.sensor_id, proto.SensorState.EnumStateType.Name(sc.state)))
                elif msg.type == proto.StatusPacket.SENSOR_FIELD:
                    logging.debug("Got a SENSOR_FIELD message")
                    for s in self.get_sensors():
                        for sc in msg.sensor_field:
                            if sc.sensor_id == s.sensor_id and msg_chassis_id == s.chassis_id:
                                logging.info("Updating fields chassis: %d sensor: %d x: %d y: %d z: %d" % (s.chassis_id, s.sensor_id, sc.field_x, sc.field_y, sc.field_z))
                                s.set_fields(sc.field_x, sc.field_y, sc.field_z)
                    self._report_sensor_status_changed()

    def update_chassis_connections(self):
        connected = set()

        for svc in self.services.values():
            if svc.chassis_name in self.chassis_name_to_id:
                connected.add(svc.chassis_name)
                self.hardware_state.add_chassis(svc.chassis_id)
                svc.cmd_sensor_config_req()
                if self._developer_mode_password:
                    svc.cmd_send_password(self._developer_mode_password)
                if self.is_streaming:
                    # If the gui is already streaming send the start cmd to the new chassis
                    svc.start_streaming()
                self._report_chassis_connection_change(svc.chassis_id, True)
            else:
                self.hardware_state.remove_chassis(svc.chassis_id)
                with self.frame_q_lock:
                    if svc.chassis_id in self.frame_q:
                        del self.frame_q[svc.chassis_id]
                self._report_chassis_connection_change(svc.chassis_id, False)
        self.streaming_sources = {svc.chassis_id: svc for svc in self.active_services.values()}

        self._handle_chassis_connections(len(connected), len(self.chassis_name_to_id))

    def _read_next_data_frame(self, sources):
        with self.frame_q_lock:
            for chassis_id in sources.keys():
                if self.is_streaming:
                    if chassis_id not in self.frame_q:
                        logging.info("New chassis_id %d for frame data" % chassis_id)
                        self.frame_q[chassis_id] = None
                        self.last_ts[chassis_id] = None
                        if len(self.frame_q) > 1:
                            self.frames_syncd = False
                            self.frame_reset_pending = True
                        else:
                            self.frames_syncd = True

                    if self.frame_q[chassis_id] is not None:
                        continue

                    try:
                        data_item = sources[chassis_id].data_queue.get(block=True, timeout=0.01)
                        self.frame_q[chassis_id] = {'timestamp': data_item.timestamp, 'data': data_item}
                        #if data_item.timestamp <= self.SYNC_THRESH:
                        if data_item.timestamp == 1:
                            self.no_sync = False
                            if chassis_id not in self.sync_active:
                                logging.info("chassis %d sync detected ts %d" % (chassis_id, data_item.timestamp))
                                self.sync_active[chassis_id] = True
                                self.frame_reset_pending = True
                                self.frames_syncd = False
                            else:
                                logging.info("chassis %d sync detected while active ts %d" % (chassis_id, data_item.timestamp))
                        elif self.last_ts[chassis_id] is not None:
                            if data_item.timestamp < self.last_ts[chassis_id]:
                                logging.warning("chassis [%d] new ts: %d less than last ts: %d" % (chassis_id, data_item.timestamp, self.last_ts[chassis_id]))
                        self.last_ts[chassis_id] = data_item.timestamp
                    except queue.Empty:
                        continue

    def _build_frame(self):
        with self.frame_q_lock:
            active_channels = self.get_channels()
            out_data = defaultdict(dict)
            ts_list = []
            for chassis_id, q in self.frame_q.items():
                ts = None
                if q:
                    ts = q['timestamp']
                ts_list.append(ts)
            # logging.info("tslist %s" % (ts_list))
            skip = any(e is None for e in ts_list)
            if skip:
                return
            equal = all(e == ts_list[0] for e in ts_list)

            chassis_to_send = []
            if self.no_sync:
                if not equal:
                    min_ts = min(ts_list)
                    for chassis_id in self.frame_q.keys():
                        if self.frame_q[chassis_id]['timestamp'] == min_ts:
                            logging.debug("Dropping timestamp for startup sync")
                            self.frame_q[chassis_id] = None
                    return out_data
                else:
                    logging.info("Got startup sync %s" % ts_list)
                    self.frames_syncd = True
                    self.no_sync = False
            elif self.frame_reset_pending:
                if equal:
                    self.frame_reset_pending = False
                    self.sync_active = {}
                    self.frames_syncd = True
                    logging.info("Frames are syncd %s" % ts_list)
                else:
                    for chassis_id, f in self.frame_q.items():
                        do_add = False
                        if chassis_id not in self.sync_active:
                            do_add = True
                        if do_add:
                            chassis_to_send.append(chassis_id)
            if self.frames_syncd:
                chassis_to_send = [i for i in self.frame_q.keys()]

            for chassis_id in chassis_to_send:
                data = self.frame_q[chassis_id]['data'].data

                for data_frame in data:
                    sensor_id = data_frame.sensor
                    sensor = self.hardware_state.get_sensor(chassis_id, sensor_id)
                    if sensor is None:
                        logging.error(f"Received data for {sensor_id} which does not exist")
                        continue

                    datatype = data_frame.datatype
                    ch_name = '%02d:%02d:%s' % (chassis_id, sensor_id, datatype)
                    try:
                        idx = [c.name for c in active_channels].index(ch_name)
                    except ValueError:   # if ch_name not in active_channels
                        logging.debug(f"{ch_name} not in {active_channels}")
                        continue

                    try:
                        out_data[ch_name]['calibration'] = active_channels[idx].calibration
                    except IndexError:
                        logging.debug(f"Could not lookup channel {ch_name} {idx}, might have been removed {active_channels}")
                        continue

                    sensor.add_data_point(ch_name, data_frame.val)
                    out_data[ch_name]['data'] = data_frame.val
                    out_data[ch_name]['sensor'] = sensor.name
                    out_data[ch_name]['idx'] = idx
                    out_data[ch_name]['sensor_id'] = sensor.sensor_id
                    out_data[ch_name]['data_type'] = int(datatype)
                self.frame_q[chassis_id] = None
            return out_data

    def _read_data_queue_thread(self):
        out_list = []
        while self.is_streaming:
            t1 = time.time()

            self._read_next_data_frame(self.streaming_sources)
            out_data = self._build_frame()

            if out_data:
                self.update_count += 1
                out_list.append(out_data)
                if len(out_list) >= 10:
                    with self.counter_lock:
                        self.counter[0] += 1
                    self._report_data_available(out_list)
                    out_list = []
            self.total_time += (time.time() - t1)
            if (self.update_count % common.PERFORMANCE_LOGGING_PERIOD == 0):
                # logging.info(f"Avg read_thread time is {self.total_time / common.PERFORMANCE_LOGGING_PERIOD}")
                self.total_time = 0
                self.update_count = 0
        logging.info("Exiting the read_data_queue thread!")

    def start(self):
        # Clear out any old stale data from the data queue
        for svc in self.active_services.values():
            svc.clear_data_queue()
        self.reset_frame_buffer()

        self.update_count = 1
        self.total_time = 0

        for svc in self.active_services.values():
            svc.start_streaming()

        self.stream_thread = threading.Thread(target=self._read_data_queue_thread)
        self.stream_thread.daemon = True
        self.stream_thread.start()

    def stop(self):
        logging.info("network data source stop")
        for svc in self.active_services.values():
            svc.stop_streaming()
        if self.stream_thread and self.stream_thread.is_alive():
            self.stream_thread.join(timeout=5)

    def set_wave_off(self, chassis_id, sensor_id):
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave_off(sensor_list=[sensor_id, ])

    def set_wave_ramp(self, chassis_id, sensor_id, freq, amp):
        self.set_wave_off(chassis_id, sensor_id)
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave(sensor_list=[(sensor_id, proto.WaveMessage.WAVE_RAMP, amp, freq), ])

    def set_wave_sine(self, chassis_id, sensor_id, freq, amp):
        self.set_wave_off(chassis_id, sensor_id)
        name = self.get_chassis_name_from_id(chassis_id)
        if name not in self.active_services:
            logging.error(f"{name} is not a registered chassis, can not send wave command")
            return
        self.active_services[name].cmd_wave(sensor_list=[(sensor_id, proto.WaveMessage.WAVE_SINE, amp, freq), ])

    def set_closed_loop(self, is_on):
        self.closed_loop_expected = is_on
        for svc in self.active_services.values():
            svc.cmd_closed_loop(is_on)
        for d in self.discovered_devices.values():
            d['closed_loop'] = None

    def check_closed_loop(self):
        unknowns = False
        all_closed = True
        all_open = True
        for chassis_name in self.active_services.keys():
            if self.discovered_devices[chassis_name]['closed_loop'] is None:
                unknowns = True
            elif not self.discovered_devices[chassis_name]['closed_loop']:
                all_closed = False
            elif self.discovered_devices[chassis_name]['closed_loop']:
                all_open = False
        if not unknowns:
            if not all_open and not all_closed:
                self.set_closed_loop(False)
            elif all_closed:
                self._report_closed_loop(True)
            elif all_open:
                self._report_closed_loop(False)
