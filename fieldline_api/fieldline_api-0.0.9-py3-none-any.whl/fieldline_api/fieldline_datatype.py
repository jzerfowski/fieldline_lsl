from enum import Enum


class FieldLineDataType(Enum):
    DATA_BZ_OPEN = 0
    DATA_BY = 1
    DATA_BX = 2
    DATA_BZ_CLOSED = 3


class FieldLineWaveType(Enum):
    WAVE_OFF = 0
    WAVE_RAMP = 1
    WAVE_SINE = 2
