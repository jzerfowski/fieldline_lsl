from enum import Enum


class FieldLineDataType(Enum):
    DATA_BZ = 0
    DATA_BY = 1
    DATA_BX = 2


class FieldLineWaveType(Enum):
    WAVE_OFF = 0
    WAVE_RAMP = 1
    WAVE_SINE = 2
